package com.myjlc;

class Hello{
public static void main (String as[]){
System.out.println("Hello Guys");
}
}
