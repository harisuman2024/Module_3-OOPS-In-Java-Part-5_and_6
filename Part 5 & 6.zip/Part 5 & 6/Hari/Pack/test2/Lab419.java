package com.myjlc.p1;

class Lab419{
public static void main(String args[]){
System.out.println(" Hello Guys !!! from p1 package");
}
} 
