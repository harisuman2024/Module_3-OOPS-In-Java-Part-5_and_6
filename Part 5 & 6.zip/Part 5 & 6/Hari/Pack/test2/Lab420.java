package com.myjlc.p2;
class Lab420{
public static void main(String args[]){
System.out.println(" Hello Guys !!! from p2 package");
}
}