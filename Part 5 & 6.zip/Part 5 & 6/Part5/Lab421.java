class Hello{
}
package com.myjlc;
class Lab421{
public static void main(String args[]){
System.out.println(" Hello Guys !!! ");
}
} 
