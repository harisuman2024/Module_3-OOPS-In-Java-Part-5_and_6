package com.myjlc.p1;
package com.myjlc.p2;
class Hello{
}
class Lab422{
public static void main(String args[]){
System.out.println(" Hello Guys !!! ");
}
} 
