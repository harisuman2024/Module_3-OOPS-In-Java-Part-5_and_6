package com.myjlc;
class Hello{ }
class Hai { }
public class Lab424{
public static void main(String args[]){
System.out.println(" Hello Guys !!! ");
}
}