package com.myjlc;
public class Hello{
public static void main(String args[]){
System.out.println(" Hello Guys !!! ");
}
}