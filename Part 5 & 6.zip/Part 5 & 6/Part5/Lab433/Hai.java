package com.myjlc.p1;
public class Hai{
public int A=10;
public static int B=20;
public void m1(){
System.out.println("Hai - m1() ");
}
public static void m2(){
System.out.println("Hai - m2() ");
}
}