package com.myjlc.p2;
public class Hello{
public int C=30;
public static int D=40;
public void m3(){
System.out.println("Hello - m3() ");
}
public static void m4(){
System.out.println("Hello - m4() ");
}
}