package com.myjlc.p3;

import static com.myjlc.p1.Hai.*;
import static com.myjlc.p2.Hello.*;

public class Lab433 {
    public static void main(String args[]) {
        System.out.println(B);
        System.out.println(D);
        m2();
        m4();
    }
}
