package com.myjlc.p3;
import static com.myjlc.p2.Hello.m4;
public class Lab434{
public static void m4(){
System.out.println("Lab435 - m4() ");
}
public static void main(String args[]){
m4();
}
} 
