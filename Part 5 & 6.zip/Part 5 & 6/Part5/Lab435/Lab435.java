package com.myjlc.p3;
import static java.lang.Math.*;
import static java.lang.System.*;
public class Lab435{
static int A=123;
public static void main(String args[]){
out.println(sqrt(25));
out.println(min(10,20));
out.println(PI);
out.println(A);
}
}