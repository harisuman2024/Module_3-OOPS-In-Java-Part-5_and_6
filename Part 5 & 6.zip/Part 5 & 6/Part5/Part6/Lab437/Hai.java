package com.myjlc.p4;
public class Hai{
protected void show(){
System.out.println("Hai - show() ");
}
}