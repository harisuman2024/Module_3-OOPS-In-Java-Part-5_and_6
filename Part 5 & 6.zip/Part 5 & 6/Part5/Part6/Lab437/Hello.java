package com.myjlc.p5;
import com.myjlc.p1.Hai;
public class Hello extends Hai{
public void m1(){
show();
}
} 
