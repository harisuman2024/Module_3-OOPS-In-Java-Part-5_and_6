package com.myjlc.p6;
import com.myjlc.p4.Hai;
import com.myjlc.p5.Hello;
class Test extends Hai{
}
public class Lab437{
public static void main(String args[]){
Test test = new Test();
test.show();
Hello hello = new Hello();
hello.m1();
}
} 