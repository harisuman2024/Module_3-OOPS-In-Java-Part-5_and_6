package com.myjlc.p1;
public class B extends A{
public void showB(){
System.out.println("showB() ");
//System.out.println(a);
System.out.println(b);
System.out.println(c);
System.out.println(d);
}
}