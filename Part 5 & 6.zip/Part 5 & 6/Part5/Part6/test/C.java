package com.myjlc.p1;
public class C{
public void showC(){
System.out.println("showC() ");
A ao = new A();
//System.out.println(ao.a);
System.out.println(ao.b);
System.out.println(ao.c);
System.out.println(ao.d);
}
}