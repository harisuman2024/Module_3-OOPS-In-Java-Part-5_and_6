package com.myjlc.p2;
import com.myjlc.p1.*;
public class D extends A{
public void showD(){
System.out.println("showD() ");
//System.out.println(a);
//System.out.println(b);
System.out.println(c);
System.out.println(d);
}
} 