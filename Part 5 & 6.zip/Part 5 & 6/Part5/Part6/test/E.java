package com.myjlc.p2;
import com.myjlc.p1.*;
public class E{
public void showE(){
System.out.println("showE() ");
A ao = new A();
//System.out.println(ao.a);
//System.out.println(ao.b);
//System.out.println(ao.c);
System.out.println(ao.d);
}
}