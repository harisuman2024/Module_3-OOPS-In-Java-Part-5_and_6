package com.myjlc.p3;
import static com.myjlc.p1.Hai.*;
import static com.myjlc.p2.Hello.*;
public class Lab431 {
public static void main(String args[]){
Hai hai = new Hai();
Hello hello=new Hello();
}
} 
