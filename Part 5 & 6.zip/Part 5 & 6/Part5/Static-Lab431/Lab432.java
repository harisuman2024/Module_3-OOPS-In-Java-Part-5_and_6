package com.myjlc.p3;
import static com.myjlc.p1.Hai.*;
import static com.myjlc.p2.Hello.*;
public class Lab432{
public static void main(String args[]){
System.out.println(A);
System.out.println(C);
m1();
m3();
}
} 