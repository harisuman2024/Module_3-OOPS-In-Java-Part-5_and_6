package com.myjlc.p1;
class Hai{
void m1(){
System.out.println("Hai - m1() ");
}
}