package com.myjlc.p1;
class Hello{
void m2(){
System.out.println("Hello - m2() ");
}
} 
