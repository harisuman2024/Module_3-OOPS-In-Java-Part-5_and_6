package com.myjlc.p1;
public class Lab426 {
public static void main(String args[]){
Hai hai = new Hai();
hai.m1();
Hello hello=new Hello();
hello.m2();
}
}
