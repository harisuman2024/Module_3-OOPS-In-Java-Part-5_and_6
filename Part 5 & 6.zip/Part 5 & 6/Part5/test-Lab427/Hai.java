package com.myjlc.p1;
public class Hai{
public void m1(){
System.out.println("Hai - m1() ");
}
}