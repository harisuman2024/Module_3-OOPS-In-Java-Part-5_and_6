package com.myjlc.p1;
public class Hello{
public void m2(){
System.out.println("Hello - m2() ");
}
} 
