package com.myjlc.p2;
import com.myjlc.p1.*;
import com.myjlc.p1.Hai;
import com.myjlc.p1.Hello;
public class Lab427 {
public static void main(String args[]){
Hai hai = new Hai();
hai.m1();
Hello hello=new Hello();
hello.m2();
}
}