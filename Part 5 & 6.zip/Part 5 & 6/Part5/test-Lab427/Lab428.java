package com.myjlc.p2;

public class Lab428 {
    public static void main(String args[]) {
        com.myjlc.p1.Hai hai = new com.myjlc.p1.Hai();
        hai.m1();
        com.myjlc.p1.Hello hello = new com.myjlc.p1.Hello();
        hello.m2();
    }
}