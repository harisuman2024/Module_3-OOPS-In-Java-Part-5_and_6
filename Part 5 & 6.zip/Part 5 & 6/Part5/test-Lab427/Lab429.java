package com.myjlc;

import java.util.ArrayList;

public class Lab429 {
    public static void main(String args[]) {
        ArrayList mylist = new ArrayList();
        java.io.File myfle = new java.io.File("hello");
        String str = new String("Ok Guys");
    }
}
