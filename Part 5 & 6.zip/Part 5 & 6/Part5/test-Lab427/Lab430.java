package com.myjlc;

import java.util.*;
import java.sql.*;

public class Lab430 {
    public static void main(String args[]) {
        java.util.Date mydate = new java.util.Date();
        System.out.println(mydate);
    }
}